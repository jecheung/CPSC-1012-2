﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdvancedPortfolio05_JordanCheung
{
    class Program
    {
        static void Main(string[] args)
        {
            selectMenu();
            
        }

        static void DisplayMenu()
        {
            Console.WriteLine("|-----------------------------|");
            Console.WriteLine("| CPSC1012 Adv. Portfolio #5  |");
            Console.WriteLine("|-----------------------------|");
            Console.WriteLine("| 1. Add Fuel                 |");
            Console.WriteLine("| 2. Drive Car                |");
            Console.WriteLine("| 0. Exit                     |");
            Console.WriteLine("|-----------------------------|");
        }

        static void selectMenu()
        {
            bool invalidInput = true;
            string choice = " ";
            double fuel = 0;
            while (invalidInput)
            {
                try
                {
                    DisplayMenu();
                    Console.Write("Option: ");
                    choice = Console.ReadLine();
                    Console.Write("\n");
                    switch (choice)
                    {
                        case "0":
                            Console.WriteLine("Good-bye - please come again ...");
                            invalidInput = false;
                            break;
                        case "1":
                             fuel = addFuel();
                            break;
                        case "2":
                            driveCar(fuel);
                            break;
                        default:
                            Console.WriteLine($"Please enter a valid number between 0 and 2");
                            break;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error: {ex.Message}");
                }
            }
        }

        static void driveCar(double n)
        {
            FuelGauge fuel = new FuelGauge();
            fuel = n;

            Odometer odometer = new Odometer(0, fuel);
            
            while (fuel.getLiters() > 0)
            {
                odometer.addMileage();
                Console.WriteLine($"Km:     {odometer.getMileage()}     Fuel: {fuel.getLiters():n2} l");

            }
        }

        static double addFuel()
        {
            FuelGauge fuel = new FuelGauge();
            Console.Write("Enter amount of fuel to add: ");
            double add = double.Parse(Console.ReadLine());
            for (int i = 0; (i < add); i++)
            {
                fuel.addLiters();
            }

            return fuel.getLiters();
        }
    }

    class Odometer
    {
        public int maxMileage = 999;

        public int KPL = 100 / 12;

        private int initialMileage;

        private int mileage;

        

        private FuelGauge fuelGauge;

        public Odometer(int m, FuelGauge FG)
        {
            initialMileage = mileage;
            mileage = m;
            fuelGauge = FG;
        }

        public int getMileage()
        {
            return mileage;
        }

        public void addMileage()
        {
            if (mileage < maxMileage)
            {
                mileage++;
            }
            else
                mileage = 0;

            int driven = initialMileage - mileage;
            if (driven % KPL == 0)
            {
                fuelGauge.burnFuel();
            }
        }
    }

    class FuelGauge
    {
        private double maxLiters = 60;

        private double liters;

        public FuelGauge()
        {
            liters = 0;
        }

        public FuelGauge(double n)
        {
            if ((liters <= maxLiters))
            {
                liters = n;
            }
            else
                liters = maxLiters;
        }
        
        public double getMaxLiters()
        {
            return maxLiters;
        }
        public double getLiters()
        {
            return liters;
        }

        public void addLiters()
        {
            if (liters < maxLiters)
            {
                liters++;
            }
            else
                Console.WriteLine("Fuel Overflow");
        }

        public void burnFuel()
        {
            if (liters > 0)
            {
                liters = liters - 0.12;
            }
            else
                Console.WriteLine("Out of Fuel ... please add fuel");
        }

    }
}
